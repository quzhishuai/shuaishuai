
function deleteCourseware(coursewareId){
	
		layer.confirm('确定删除吗？', function(index){
			layer.close(index);
			
			var loadingIndex = layer.load(1, {
		    	  shade: [0.1,'#fff'] //0.1透明度的白色背景
			});

		});  
  }

//搜索按钮 
$(function(){
	//出现滚动条固定在底部
	$(".table-content").mCustomScrollbar({
	    theme: 'minimal-dark',
	    axis: 'x',
	    scrollbarPosition: 'outside',
	    scrollInertia: 0,
	    autoDraggerLength: true, // 是否自动调整滚动条的长度 true(default)|false
	    autoHideScrollbar: false, // 是否自动隐藏滚动条
	    autoExpandScrollbar: true,
	    mouseWheel: { // 滚轮设置
	        enable: false, // 是否可以用滚轮进行滚动
	        scrollAmount: 'auto', // 内容滚动的距离， "auto"将根据情况自动调整滚动量
	        preventDefault: true //当 当前容器的滚动条在两端时，是否接着滚动父级容器的滚动条 true(default) | false
	    },
	    advanced: { // 高级设置
	        updateOnContentResize: true, // 当内容，容器或窗口发生变化时，是否自动更新滚动条
	        updateOnSelectorChange: 'td', // 当特定元素的个数发生变化时，是否自动更新滚动条
	        autoUpdateTimeout: 40 // 设置自动更新的时间（单位:ms），默认是60ms
	    },
	    callbacks: {
	        // 当水平方向出现滚动条时
	        onOverflowX: function() {
	            console.log('水平方向出现了滚动条');
	            $('#mCSB_1_scrollbar_horizontal').css({ 'position': 'fixed', 'bottom': '36px', 'left': '30px' })
	        }
	    }
	});
	
	
 layui.use(['laypage', 'layer'], function() {
	        //分页器
	        initPage(0);       
    }); 
$("#btn-primary").click(function () {  
	var pageSize = parseInt($("#page select").val());
	searchCoursewareList(1, pageSize, true);
 });

$("#btn-default").click(function () {  
	$("#coursewareUnitName").val('');
	$("#label").val('');
	$("#typeId").val('')
	$("#coursewareName").val('')
	$("#utime").val('')
});

function searchCoursewareList(pageIndex, pageSize, isFrist){

	var coursewareUnitName = $.trim($("#coursewareUnitName").val());
	var label = $.trim($("#label").val());
	var typeId= $("#typeId").val();
	var coursewareName= $.trim($("#coursewareName").val());
	var utime= $("#utime").val();
	
	var loadingIndex = layer.load(1, {
  	  shade: [0.1,'#fff'] //0.1透明度的白色背景
	});
	
		
  }
//-------------------------------------------------------------------------------
     //表格显示隐藏
		$('.table-content').on('click','.addDown',function () {
			$(this).parent('td').parent('tr').nextAll('tr').toggle('fast');
			if($(this).parent('td').parent('tr').nextAll('tr').css('opacity')==0){
				$(this).text('-')
			}else{
				$(this).text('+')
			}
			
		})
		$('.table-content').on('click','.cUp span',function(){
			$(this).closest('thead').nextAll('tbody').toggle('fast');
			if($(this).closest('thead').nextAll('tbody').css('opacity')==0){
				$(this).text('-')
			}else{
				$(this).text('+')
			}
		})

		function logoClick() {
			$('#tab_tab_home_manage').addClass('active').click();
		}

		

		//日期选择
		layui.use('laydate', function () {
			var laydate = layui.laydate;
			laydate.render({
				elem: '#startTime' //指定元素
			});
			laydate.render({
				elem: '#endTime' //指定元素
			});
		})
		layui.use('laydate', function () {
			var laydate = layui.laydate;
			laydate.render({
				elem: '#time',
				type: 'month'
			});
		})
		layui.use('laydate', function () {
			var laydate = layui.laydate;
			laydate.render({
				elem: '#utime'
			})
		});		
		function initPage(countValue) {
			$("#countValueSpan").text(countValue);			
			//分页器
			layui.laypage.render({
	            elem: 'page',
	            count: countValue,
	            layout: ['count', 'prev', 'page', 'next', 'limit', 'skip'],
	            jump: function(obj, first) {
	            	if(!first) {
	            		searchCoursewareList(obj.curr, obj.limit);
	            	}
	            }
	        });		
		}
		layui.use(['layer'],function(){
			var loadingIndex = layer.load(1, {
		    	  shade: [0.1,'#fff'] //0.1透明度的白色背景
			});
			layer.close(loadingIndex);
			
		});
		
})