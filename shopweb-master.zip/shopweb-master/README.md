# my-project

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

跟着教程做的一个vue的电商项目，使用到vue-router，vue-resource等，后台是假后台mock，数据存放到db.json当中

部分截图
![1](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/1.png)
![2](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/2.png)
![3](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/3.png)
![4](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/4.png)
![5](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/5.png)
![6](https://github.com/chiuwingyan/shopweb/blob/master/src/assets/6.png)
