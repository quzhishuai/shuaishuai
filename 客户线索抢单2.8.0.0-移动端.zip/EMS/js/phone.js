$(function () { 
    // $('.audit_status').on('touchstart', function () {
    //     console.log(123);
    // });

    // 下拉刷新
    //  添加'refresh'监听器
    $(document).on('refresh', '.pull-to-refresh-content', function (e) {
        // 模拟2s的加载过程
        setTimeout(function () {
            var cardNumber = $(e.target).find('.card').length + 1;
            var cardHTML = '<div class="card">\
                                <div class="card-content">\
                                    <div class="card-content-inner">\
                                        <p>\
                                            <span class="people">王国宇</span>\
                                            <span class="phone">13917860353</span>\
                                            <span class="city">上海</span>\
                                        </p>\
                                        <p>\
                                            <span class="time">2018-05-20 14:23:11</span>\
                                            <span class="audit">待审核</span>\
                                        </p>\
                                        <span class="icon icon-right"></span>\
                                    </div>\
                                </div>\
                            </div>';

            $(e.target).find('.card-container').prepend(cardHTML);
            // 加载完毕需要重置
            $.pullToRefreshDone('.pull-to-refresh-content');
        }, 2000);
    });

     // 列表跳转界面
    $('.card-container').bind('click', function () {
        window.location.href = 'auditPage.html';  //跳转审核界面
    });

    //时间选择器
    $("#datetime-picker").datetimePicker({
        value: ['2018', '05', '10', '18', '00']
    });

    //textarea提示
    $('.item-input #comment').on('focus', function () {
        console.log(111);
        var that = this;
        var textareaVal = $('.item-input #comment').val(); //清空textarea
        if (textareaVal == '') {
            $(this).next('.textarea_title').show();
        }
        //判断textarea_title显示,选择一行提示信息
        if ($(that).next('.textarea_title').css('display') == 'block') {
            $('.textarea_title li').unbind('click').bind('click', function () {
                $('.textarea_title').hide();
                $(that).val($(this).text())
            })
        }
    });
    
    //保存按钮
    $('.button-success').on('click',function () { 
        $.showPreloader();
        setTimeout(function () {
            $.hidePreloader();
        }, 2000);
    });
})