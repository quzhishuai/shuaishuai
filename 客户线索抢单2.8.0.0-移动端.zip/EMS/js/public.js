/*
 * @Author: gaodelong
 * @Date: 2018-04-10 10:05:24 
 * @Last Modified by: gaodelong
 * @Last Modified time: 2018-05-09 18:21:30
 */

//input清空
function clearInput() {
  $(".cleanInput").click(function () {
    $(".empty").val("");
  });
}
//侧边栏伸缩
function menuToggle() {
  $(".sidebar-menu .menu-dropdown").click(function () {
    $(this)
      .next(".submenu")
      .slideToggle("500");
  });
}
// 侧边栏 li--active
function liActive(){
  $('.sidebar-menu .submenu li').click(function () { 
    console.log(1);
    
    $('.sidebar-menu .submenu li').removeClass('li_on');
    $(this).addClass('li_on')
  })

}

//退出登录
function Exit() {
  layui.use("layer", function () {
    var $ = layui.jquery,
      layer = layui.layer;
    layer.open({
      title: "提示信息",
      content: $(".layercon-exit").html(),
      area: ["350px", ""],
      btn: ["确定", "取消"],
      yes: function (index) {
        layer.close(index);
        location.href = "logout";
      }
    });
  });
}

// 日期时间选择器
function dateTime() {
  var minDateTime; //选定的开始时间
  layui.use("laydate", function () {
    var $ = layui.jquery,
      laydate = layui.laydate;
    //开始日期
    laydate.render({
      elem: "#datetimeBegin",
      done: function (value, date) {
        minDateTime = value;

        //结束日期最小限定
        if (minDateTime) {
          console.log(minDateTime);
          laydate.render({
            elem: "#datetimeEnd",
            min: minDateTime
          });
        }
      }
    });
  });
}

// textarea提示信息
function textareaTit() { 
  $('.layui-input-block #comment').focus(function () { 
    var that = this;
    var textareaVal = $('.layui-input-block #comment').val();  //清空textarea
    if (textareaVal == '') {
      $(this).next('.textarea_title').show();
      
    }
    //判断textarea_title显示,选择一行提示信息
    if ($(that).next('.textarea_title').css('display') == 'block') {
      $('.textarea_title li').unbind('click').bind('click',function () { 
        $('.textarea_title').hide();
        $(that).val($(this).text())
      })
    }
  });
}

// 提交成功弹框
function submitModule() {
  $('#saveBtn').click(function () { 
    layui.use("layer", function () {
      var $ = layui.jquery,
        layer = layui.layer;
      layer.open({
        title: ["审核", "text-align: center;padding-left: 85px;"],
        content: $(".submitModule").html(),
        area: ["380px", ""],
        btn: ["确定"],
        yes: function (index) {
          layer.close(index);
        },
        success: function (param) {

        }
      });
    });
  })
} 
function emailMessage() { 
  
  $('.manyMessage').click(function () { 
    if ($('.email_text').css('display') == 'none') {
      $(this).next('.email_text').show(300)
    }else{
      $(this).next('.email_text').hide(300)
    }
  });
}